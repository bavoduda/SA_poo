/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.ClienteDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno_Tarde
 */
public class ClienteDAO {
    
    
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<ClienteDTO> list = new ArrayList<>();
    
    public ResultSet autenticacaoUsuario(ClienteDTO objclientedto){
    
        conn = new ConexaoDAO().conectaBD();
        
        try {
            
            String sql = "select * from cliente where user = ? and senha = ?";
            
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, objclientedto.getUser());
            pstm.setString(2, objclientedto.getSenha());
            
            ResultSet rs = pstm.executeQuery();
            return rs;
            
            
            
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, "UsuarioDAO: " + error);
            return null;
        }
        
    }
    
    public void cadastrarCliente(ClienteDTO objclientedto) { 
        
    String sql = "insert into cliente (nome, cpf, cnh, endereco, telefone, email, idade, sexo, user, senha) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";    
    conn = new ConexaoDAO().conectaBD();
    
    try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objclientedto.getNome());
            pstm.setString(2, objclientedto.getCpf());
            pstm.setInt(3, objclientedto.getCnh());
            pstm.setString(4, objclientedto.getEndereco());
            pstm.setString(5, objclientedto.getTelefone());
            pstm.setString(6, objclientedto.getEmail());
            pstm.setInt(7, objclientedto.getIdade());
            pstm.setString(8, objclientedto.getSexo());
            pstm.setString(9, objclientedto.getUser());
            pstm.setString(10, objclientedto.getSenha());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException error) {
            JOptionPane.showInternalConfirmDialog(null, "ClienteDAO" + error);
        }
    
    }
    
    public ArrayList<ClienteDTO> ListarCliente() {
    
        String sql = "select * from cliente";
        conn = new ConexaoDAO().conectaBD();
        try {
            
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()){
                ClienteDTO objClienteDTO = new ClienteDTO();
                objClienteDTO.setId_cliente(rs.getInt("id_cliente"));
                objClienteDTO.setNome(rs.getString("nome"));
                objClienteDTO.setCpf(rs.getString("cpf"));
                objClienteDTO.setCnh(rs.getInt("cnh"));
                objClienteDTO.setEndereco(rs.getString("endereco"));
                objClienteDTO.setTelefone(rs.getString("telefone"));
                objClienteDTO.setEmail(rs.getString("email"));
                objClienteDTO.setIdade(rs.getInt("idade"));
                objClienteDTO.setSexo(rs.getString("sexo"));
                objClienteDTO.setUser(rs.getString("user")); 
                
                list.add(objClienteDTO);
            }
            
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, "ListarClienteDAO: " + error);
        }
        
        return list;
        
    }
    
    public void alterarDados(ClienteDTO objclientedto){
    
        String sql = "update cliente set nome = ?, cpf = ?, cnh = ?, endereco = ?, telefone = ?, email = ?, idade = ?, sexo = ?, user = ?, senha = ? where id_cliente = ?";
    
         conn = new ConexaoDAO().conectaBD();
    
    try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objclientedto.getNome());
            pstm.setString(2, objclientedto.getCpf());
            pstm.setInt(3, objclientedto.getCnh());
            pstm.setString(4, objclientedto.getEndereco());
            pstm.setString(5, objclientedto.getTelefone());
            pstm.setString(6, objclientedto.getEmail());
            pstm.setInt(7, objclientedto.getIdade());
            pstm.setString(8, objclientedto.getSexo());
            pstm.setString(9, objclientedto.getUser());
            pstm.setString(10, objclientedto.getSenha());
            pstm.setInt(11, objclientedto.getId_cliente());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException error) {
            JOptionPane.showInternalConfirmDialog(null, "ClienteDAO AlterarDados: " + error);
        }
        
    }
    
}
