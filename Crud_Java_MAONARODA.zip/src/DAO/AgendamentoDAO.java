/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.AgendamentoDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author nikol
 */
public class AgendamentoDAO {
    
    Connection conn;
    PreparedStatement pstm;
    
    public void cadastrarAgendamento(AgendamentoDTO objagendamentodto) { 
        
    String sql = "insert into agendamento (nome, data_visita, horario) values (?, ?, ?)";    
    conn = new ConexaoDAO().conectaBD();
    
    try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objagendamentodto.getNome());
            pstm.setString(2, objagendamentodto.getData_visita());
            pstm.setString(3, objagendamentodto.getHorario());
            
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException error) {
            JOptionPane.showInternalConfirmDialog(null, "AgendamentoDAO" + error);
        }
    
    }
    
    
    
    
    
    
    
    
}
